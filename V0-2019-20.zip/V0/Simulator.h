#ifndef SIMULATOR_H
#define SIMULATOR_H


// Overall constants

// Monoprogrammed system (a very primitive one)
#define MAXNUMPROCESSES 1

// Maximum number of user programs in command line (not used in this version)
#define MAXNUMUSERPROGRAMS 20


#endif
